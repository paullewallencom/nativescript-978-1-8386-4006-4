# Learning-NativeScript-V

After cloning, in the directory type 
```
npm install
```
To run Android:
```
tns run android --bundle
```
To run iOS:
```
tns run ios --bundle
```
